import Link from "next/link";
import { Logo } from "@/components/Logo";

export default function HomePage() {
  return (
    <>
      <Hero />
      <Problem />
      <Services />
      <AutomationMenu />
      <Trust />
      <CTA />
    </>
  );
}

function Hero() {
  return (
    <section className="relative pt-32 pb-20 lg:pt-40 lg:pb-32 overflow-hidden">
      {/* Background decoration */}
      <div className="absolute inset-0 -z-10">
        <div className="absolute top-0 right-0 w-1/2 h-1/2 bg-gradient-to-bl from-primary-100/50 to-transparent rounded-full blur-3xl" />
        <div className="absolute bottom-0 left-0 w-1/3 h-1/3 bg-gradient-to-tr from-primary-100/30 to-transparent rounded-full blur-3xl" />
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto text-center">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary-50 border border-primary-100 mb-8">
            <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></span>
            <span className="text-sm font-medium text-primary-700">Now serving Chicago small businesses</span>
          </div>

          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-gray-900 leading-tight mb-6">
            You've Heard About AI.
            <br />
            <span className="gradient-text">I'll Show You What to Do With It.</span>
          </h1>

          <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
            Done-for-you automation for Chicago small businesses. 
            Save 5+ hours/week without learning a single tool. 
            One-week delivery, guaranteed.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-8">
            <Link href="/contact" className="btn btn-primary text-lg py-4 px-8">
              Get Your Free AI Audit
            </Link>
            <Link href="#services" className="btn btn-secondary text-lg py-4 px-8">
              See How It Works
            </Link>
          </div>

          <div className="flex items-center justify-center gap-8 text-sm text-gray-500">
            <div className="flex items-center gap-2">
              <svg className="w-5 h-5 text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
              </svg>
              <span>No tech skills needed</span>
            </div>
            <div className="flex items-center gap-2">
              <svg className="w-5 h-5 text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
              </svg>
              <span>One-week delivery</span>
            </div>
            <div className="flex items-center gap-2">
              <svg className="w-5 h-5 text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
              </svg>
              <span>Local to Chicago</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function Problem() {
  const problems = [
    {
      emoji: "😰",
      title: "Analysis Paralysis",
      description: "Everyone's talking about AI but you don't know where to start or what tools to use"
    },
    {
      emoji: "⏰",
      title: "Time Drain",
      description: "You spend 2+ hours every day on emails, follow-ups, and repetitive tasks"
    },
    {
      emoji: "💸",
      title: "Lost Revenue",
      description: "You lose leads because you can't respond fast enough to hot prospects"
    }
  ];

  return (
    <section className="py-20 bg-gray-50">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">Sound Familiar?</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            You're not alone. Most small business owners know AI could help them, 
            but they're too busy running their business to figure it out.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-6">
          {problems.map((problem, index) => (
            <div key={index} className="card p-8 text-center">
              <div className="text-4xl mb-4">{problem.emoji}</div>
              <h3 className="font-semibold text-lg text-gray-900 mb-2">{problem.title}</h3>
              <p className="text-gray-600">{problem.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function Services() {
  const services = [
    {
      tier: "TIER 1",
      name: "AI Kickstart",
      price: "$500",
      priceNote: "one-time",
      description: "Get your team set up and using AI in one session.",
      features: [
        "1-hour AI workshop for your team",
        "ChatGPT Team setup (4-5 seats)",
        "Custom prompt library (15 prompts)",
        "Automation opportunity audit",
        "30 days of email support"
      ],
      cta: "Book Now",
      popular: false
    },
    {
      tier: "TIER 2",
      name: "Workflow Automation",
      price: "$1,500 – $3,000",
      priceNote: "+ $150-250/month maintenance",
      description: "One working automation that saves you 5+ hours/week.",
      features: [
        "Choose from 6 proven automations",
        "Custom-built for your workflow",
        "Built in 5-7 business days",
        "30 days of tweaks & fixes",
        "Monthly monitoring & support",
        "ROI tracking dashboard"
      ],
      cta: "Get Started",
      popular: true
    },
    {
      tier: "TIER 3",
      name: "AI Agent System",
      price: "Custom",
      priceNote: "starting at $3,000 + monthly retainer",
      description: "Your own 24/7 AI system with multiple custom automations.",
      features: [
        "OpenClaw deployment (branded)",
        "3+ custom automated workflows",
        "Daily/weekly cron jobs",
        "Weekly activity reports",
        "Priority support",
        "Quarterly strategy reviews"
      ],
      cta: "Book a Call",
      popular: false
    }
  ];

  return (
    <section id="services" className="py-24 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-4">Three Ways I Can Help</h2>
          <p className="text-xl text-gray-600">Pick what fits. No enterprise BS.</p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <div
              key={index}
              className={`card p-8 relative ${
                service.popular 
                  ? "border-2 border-primary-500 shadow-xl scale-105" 
                  : "hover:border-primary-300"
              }`}
            >
              {service.popular && (
                <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                  <span className="bg-primary-600 text-white text-xs font-bold px-4 py-1.5 rounded-full uppercase tracking-wide">
                    Most Popular
                  </span>
                </div>
              )}

              <div className="text-sm font-semibold text-primary-600 mb-2">{service.tier}</div>
              <h3 className="text-2xl font-bold text-gray-900 mb-2">{service.name}</h3>
              
              <div className="mb-4">
                <div className="text-4xl font-bold text-gray-900">{service.price}</div>
                <div className="text-gray-500 text-sm">{service.priceNote}</div>
              </div>

              <p className="text-gray-600 mb-6">{service.description}</p>

              <ul className="space-y-3 mb-8">
                {service.features.map((feature, fIndex) => (
                  <li key={fIndex} className="flex items-start gap-3">
                    <svg className="w-5 h-5 text-green-500 flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                    </svg>
                    <span className="text-gray-700">{feature}</span>
                  </li>
                ))}
              </ul>

              <Link
                href="/contact"
                className={`block text-center py-3 px-6 rounded-lg font-semibold transition-all ${
                  service.popular
                    ? "btn-primary"
                    : "btn-outline"
                }`}
              >
                {service.cta}
              </Link>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function AutomationMenu() {
  const automations = [
    {
      icon: "⚡",
      title: "Instant Lead Response",
      description: "Auto-reply to form fills and emails within 5 minutes. Never lose a hot lead again.",
      timeSaved: "2 hrs/week"
    },
    {
      icon: "🔍",
      title: "Meeting Prepper",
      description: "Auto-research every lead before your call. Send you a briefing email 30 min prior.",
      timeSaved: "3 hrs/week"
    },
    {
      icon: "✍️",
      title: "Content Generator",
      description: "Turn your voice notes into weekly blog posts and social content. Fully automated.",
      timeSaved: "4 hrs/week"
    },
    {
      icon: "📧",
      title: "Follow-Up Sequences",
      description: "Smart email nurture sequences that trigger based on prospect behavior.",
      timeSaved: "2 hrs/week"
    },
    {
      icon: "📄",
      title: "Document Processor",
      description: "Extract data from PDFs and emails straight to your spreadsheet or CRM.",
      timeSaved: "3 hrs/week"
    },
    {
      icon: "⭐",
      title: "Review Requester",
      description: "Auto-request reviews after project completion. Follow up once if no response.",
      timeSaved: "1 hr/week"
    }
  ];

  return (
    <section className="py-24 bg-gray-50">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-4">Choose Your Automation</h2>
          <p className="text-xl text-gray-600">Pick one. I'll build it. One week delivery.</p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {automations.map((automation, index) => (
            <div key={index} className="card p-6 group">
              <div className="flex items-start gap-4">
                <div className="text-3xl">{automation.icon}</div>
                <div className="flex-1">
                  <h3 className="font-semibold text-lg text-gray-900 mb-2 group-hover:text-primary-600 transition-colors">
                    {automation.title}
                  </h3>
                  <p className="text-gray-600 text-sm mb-3">{automation.description}</p>
                  <div className="inline-flex items-center gap-1 text-xs font-medium text-green-600 bg-green-50 px-2 py-1 rounded-full">
                    <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                    Save {automation.timeSaved}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function Trust() {
  const benefits = [
    {
      icon: "🚀",
      title: "One Week Delivery",
      description: "No 3-month projects. Working automation in 5-7 business days."
    },
    {
      icon: "🎯",
      title: "No Tech Skills Needed",
      description: "I handle everything. You get results, not homework."
    },
    {
      icon: "🏠",
      title: "Chicago Local",
      description: "I understand Chicago small business. Available for in-person when needed."
    },
    {
      icon: "🛡️",
      title: "30-Day Guarantee",
      description: "Not happy? I'll keep tweaking until it's right. No extra cost."
    }
  ];

  return (
    <section className="py-24 px-4 sm:px-6 lg:px-8">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-4">Why Work With Me?</h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            I built Flowstate AI because I was tired of seeing small businesses 
            get sold overpriced, overcomplicated solutions.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {benefits.map((benefit, index) => (
            <div key={index} className="text-center">
              <div className="text-4xl mb-4">{benefit.icon}</div>
              <h3 className="font-semibold text-lg text-gray-900 mb-2">{benefit.title}</h3>
              <p className="text-gray-600">{benefit.description}</p>
            </div>
          ))}
        </div>

        {/* Be First Success Story CTA */}
        <div className="mt-20 text-center">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary-50 border border-primary-100 mb-4">
            <svg className="w-4 h-4 text-primary-600" fill="currentColor" viewBox="0 0 20 20">
              <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
            </svg>
            <span className="text-sm font-medium text-primary-700">Real Results, Not Fake Reviews</span>
          </div>
          <h3 className="text-2xl font-bold text-gray-900 mb-4">Be Our First Success Story</h3>
          <p className="text-gray-600 max-w-xl mx-auto mb-8">
            Flowstate AI is new, but I'm not new to delivering results. 
            I come from technology consulting where I helped PE firms identify 
            AI value creation opportunities. Let's make your business the case study.
          </p>
          <Link href="/contact" className="btn btn-outline">
            Let's Talk
          </Link>
        </div>
      </div>
    </section>
  );
}

function CTA() {
  return (
    <section className="py-24 bg-primary-600 relative overflow-hidden">
      {/* Background decoration */}
      <div className="absolute inset-0 -z-0">
        <div className="absolute top-0 left-0 w-96 h-96 bg-white/5 rounded-full blur-3xl -translate-x-1/2 -translate-y-1/2" />
        <div className="absolute bottom-0 right-0 w-96 h-96 bg-white/5 rounded-full blur-3xl translate-x-1/2 translate-y-1/2" />
      </div>

      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
        <h2 className="text-3xl sm:text-4xl font-bold text-white mb-4">
          Get Your Free AI Audit
        </h2>
        <p className="text-xl text-primary-100 mb-8">
          20-minute call. I'll identify 2-3 automations specific to your business.
          <br />
          No pitch. Just insights you can use.
        </p>

        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Link
            href="/contact"
            className="inline-flex items-center justify-center gap-2 bg-white text-primary-700 px-8 py-4 rounded-lg font-semibold text-lg hover:bg-gray-100 transition-colors"
          >
            Book Your Free Audit
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8l4 4m0 0l-4 4m4-4H3" />
            </svg>
          </Link>
        </div>

        <p className="text-primary-200 mt-6 text-sm">
          Or email me directly: <a href="mailto:hello@flowstateai.io" className="underline hover:text-white">hello@flowstateai.io</a>
        </p>
      </div>
    </section>
  );
}
