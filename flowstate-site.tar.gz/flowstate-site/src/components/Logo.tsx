interface LogoProps {
  className?: string;
}

export function Logo({ className = "w-8 h-8" }: LogoProps) {
  return (
    <svg
      viewBox="0 0 40 40"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
    >
      {/* Background gradient */}
      <defs>
        <linearGradient id="logoGradient" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#3b82f6" />
          <stop offset="100%" stopColor="#1d4ed8" />
        </linearGradient>
        <linearGradient id="logoGradientAlt" x1="100%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%" stopColor="#60a5fa" />
          <stop offset="100%" stopColor="#2563eb" />
        </linearGradient>
      </defs>
      
      {/* Outer circle */}
      <circle
        cx="20"
        cy="20"
        r="18"
        stroke="url(#logoGradient)"
        strokeWidth="2.5"
        fill="none"
      />
      
      {/* Inner flow lines - representing flow/continuous improvement */}
      <path
        d="M10 20C10 20 14 14 20 14C26 14 30 20 30 20"
        stroke="url(#logoGradient)"
        strokeWidth="2.5"
        strokeLinecap="round"
        fill="none"
      />
      <path
        d="M12 24C12 24 15.5 19 20 19C24.5 19 28 24 28 24"
        stroke="url(#logoGradientAlt)"
        strokeWidth="2"
        strokeLinecap="round"
        fill="none"
        opacity="0.7"
      />
      
      {/* Center dot - representing the AI/core */}
      <circle
        cx="20"
        cy="20"
        r="3"
        fill="url(#logoGradient)"
      />
    </svg>
  );
}

export function LogoWithText({ className = "" }: { className?: string }) {
  return (
    <div className={`flex items-center gap-3 ${className}`}>
      <Logo className="w-10 h-10" />
      <span className="text-2xl font-bold text-gray-900">
        Flowstate<span className="text-primary-600">AI</span>
      </span>
    </div>
  );
}
