import Link from "next/link";
import { Logo } from "@/components/Logo";

export default function HomePage() {
  return (
    <>
      <Hero />
      <Examples />
      <Services />
      <AutomationExamples />
      <Trust />
      <CTA />
    </>
  );
}

function Hero() {
  return (
    <section className="relative min-h-screen pt-32 pb-20 lg:pt-40 lg:pb-32 overflow-hidden bg-slate-950">
      {/* Animated background elements */}
      <div className="absolute inset-0 -z-10">
        {/* Gradient mesh */}
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(59,130,246,0.15),transparent_50%)]" />
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl animate-pulse" />
        <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-indigo-500/10 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '1s' }} />
        
        {/* Grid pattern */}
        <div className="absolute inset-0 bg-[linear-gradient(rgba(59,130,246,0.03)_1px,transparent_1px),linear-gradient(90deg,rgba(59,130,246,0.03)_1px,transparent_1px)] bg-[size:60px_60px]" />
        
        {/* Floating particles */}
        <div className="absolute top-20 left-10 w-2 h-2 bg-blue-400/40 rounded-full animate-bounce" style={{ animationDuration: '3s' }} />
        <div className="absolute top-40 right-20 w-3 h-3 bg-indigo-400/30 rounded-full animate-bounce" style={{ animationDuration: '4s', animationDelay: '1s' }} />
        <div className="absolute bottom-40 left-1/3 w-2 h-2 bg-cyan-400/40 rounded-full animate-bounce" style={{ animationDuration: '3.5s', animationDelay: '0.5s' }} />
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="max-w-4xl mx-auto text-center">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-blue-500/10 border border-blue-500/20 mb-8">
            <span className="w-2 h-2 rounded-full bg-blue-400 animate-pulse"></span>
            <span className="text-sm font-medium text-blue-300">AI-Powered Automation for Chicago Small Business</span>
          </div>

          <h1 className="text-4xl sm:text-5xl lg:text-7xl font-bold text-white leading-tight mb-6 tracking-tight">
            Automate Any Process.
            <br />
            <span className="text-blue-400">Build Any Tool.</span>
            <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-indigo-400">
              Transform Your Business.
            </span>
          </h1>

          <p className="text-xl text-slate-400 mb-8 max-w-2xl mx-auto">
            Flowstate AI builds custom AI automations and intelligent tools 
            that save you 10+ hours every week. No code. No complexity. Just results.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
            <Link href="/contact" className="btn bg-blue-500 hover:bg-blue-600 text-white text-lg py-4 px-8 rounded-xl shadow-lg shadow-blue-500/25 transition-all">
              Get Your Free AI Audit
            </Link>
            <Link href="#examples" className="btn bg-slate-800/50 hover:bg-slate-800 text-white border border-slate-700 text-lg py-4 px-8 rounded-xl transition-all">
              See AI Automations
            </Link>
          </div>

          <div className="flex items-center justify-center gap-8 text-sm text-slate-500">
            <div className="flex items-center gap-2">
              <svg className="w-5 h-5 text-blue-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
              </svg>
              <span>Custom AI Tools Built For You</span>
            </div>
            <div className="flex items-center gap-2">
              <svg className="w-5 h-5 text-blue-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
              </svg>
              <span>One-Week Delivery</span>
            </div>
            <div className="flex items-center gap-2">
              <svg className="w-5 h-5 text-blue-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
              </svg>
              <span>Chicago-Based</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function Examples() {
  const examples = [
    {
      title: "You'll Save 10+ Hours Every Week",
      description: "Our AI automations handle your repetitive tasks—lead follow-ups, document processing, meeting prep—so you can focus on growing your business.",
      icon: "⚡",
      color: "from-blue-500 to-cyan-400"
    },
    {
      title: "You'll Never Lose a Hot Lead Again",
      description: "AI-powered instant response systems engage prospects within minutes, 24/7. Every inquiry gets a personalized reply while you sleep.",
      icon: "🎯",
      color: "from-indigo-500 to-purple-400"
    },
    {
      title: "You'll Make Smarter Decisions Faster",
      description: "Custom AI tools analyze your data, research leads before calls, and surface insights that help you close more deals with confidence.",
      icon: "🧠",
      color: "from-violet-500 to-pink-400"
    }
  ];

  return (
    <section id="examples" className="py-24 bg-slate-950 relative overflow-hidden">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_70%,rgba(59,130,246,0.08),transparent_50%)]" />
      
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center mb-16">
          <h2 className="text-3xl sm:text-4xl font-bold text-white mb-4">
            What AI Automation Can Do For You
          </h2>
          <p className="text-xl text-slate-400 max-w-2xl mx-auto">
            Real examples of how small businesses use our custom AI tools to work smarter, not harder.
          </p>
        </div>

        <div className="space-y-16">
          {examples.map((example, index) => (
            <div key={index} className={`flex flex-col ${index % 2 === 1 ? 'md:flex-row-reverse' : 'md:flex-row'} gap-8 items-center`}>
              <div className="flex-1">
                <div className={`inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-gradient-to-br ${example.color} mb-6 text-3xl`}>
                  {example.icon}
                </div>
                <h3 className="text-2xl sm:text-3xl font-bold text-white mb-4">{example.title}</h3>
                <p className="text-slate-400 text-lg leading-relaxed">{example.description}</p>
              </div>
              <div className="flex-1">
                <div className="relative">
                  <div className={`absolute -inset-4 bg-gradient-to-r ${example.color} opacity-20 rounded-3xl blur-xl`} />
                  <div className="relative bg-slate-900/80 border border-slate-800 rounded-2xl p-8">
                    <div className="space-y-4">
                      <div className="flex items-center gap-3">
                        <div className="w-3 h-3 rounded-full bg-green-400 animate-pulse" />
                        <span className="text-slate-300">AI Agent Active</span>
                      </div>
                      <div className="h-2 bg-slate-800 rounded-full overflow-hidden">
                        <div className={`h-full bg-gradient-to-r ${example.color} w-3/4 animate-pulse`} />
                      </div>
                      <p className="text-sm text-slate-500">Processing incoming requests...</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function Services() {
  const services = [
    {
      tier: "AI FOUNDATION",
      name: "AI Kickstart",
      description: "Get your team up and running with AI. One session, custom setup, immediate productivity gains.",
      features: [
        "Team AI workshop & training",
        "ChatGPT Team setup & prompts",
        "Custom AI tool recommendations",
        "Automation opportunity audit",
        "30 days support"
      ],
      cta: "Get Started",
      highlight: false
    },
    {
      tier: "MOST POPULAR",
      name: "AI Workflow Automation",
      description: "One powerful AI automation built for your specific workflow. Save 10+ hours every week.",
      features: [
        "Custom AI automation built for you",
        "Choose from proven templates or bespoke",
        "5-7 day delivery",
        "30 days unlimited tweaks",
        "Ongoing monitoring & optimization",
        "Monthly performance reports"
      ],
      cta: "Build My Automation",
      highlight: true
    },
    {
      tier: "ENTERPRISE",
      name: "AI Agent System",
      description: "Your complete AI infrastructure. Multiple automations, custom AI agents, full transformation.",
      features: [
        "Multiple AI automations",
        "Custom AI agents & tools",
        "Branded AI deployment",
        "Advanced integrations",
        "Priority support & strategy",
        "Quarterly business reviews"
      ],
      cta: "Book a Call",
      highlight: false
    }
  ];

  return (
    <section id="services" className="py-24 bg-slate-950 relative">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_70%_30%,rgba(99,102,241,0.08),transparent_50%)]" />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center mb-16">
          <h2 className="text-3xl sm:text-4xl font-bold text-white mb-4">
            Three Ways to Transform with AI
          </h2>
          <p className="text-xl text-slate-400">
            Start with training, automate one workflow, or build a complete AI system.
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8 items-stretch">
          {services.map((service, index) => (
            <div
              key={index}
              className={`relative rounded-2xl p-8 flex flex-col h-full ${
                service.highlight
                  ? 'bg-slate-900/80 border-2 border-blue-500/50 shadow-lg shadow-blue-500/10'
                  : 'bg-slate-900/50 border border-slate-800'
              }`}
            >
              {service.highlight && (
                <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                  <span className="bg-blue-500 text-white text-xs font-bold px-4 py-1.5 rounded-full uppercase tracking-wide">
                    {service.tier}
                  </span>
                </div>
              )}
              
              {!service.highlight && (
                <div className="text-xs font-semibold text-slate-500 mb-2 tracking-wide">{service.tier}</div>
              )}
              
              <h3 className="text-2xl font-bold text-white mb-3">{service.name}</h3>
              <p className="text-slate-400 mb-6 flex-grow">{service.description}</p>
              
              <ul className="space-y-3 mb-8">
                {service.features.map((feature, fIndex) => (
                  <li key={fIndex} className="flex items-start gap-3">
                    <svg className="w-5 h-5 text-blue-400 flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                    </svg>
                    <span className="text-slate-300 text-sm">{feature}</span>
                  </li>
                ))}
              </ul>
              
              <Link
                href="/contact"
                className={`block text-center py-3 px-6 rounded-xl font-semibold transition-all mt-auto ${
                  service.highlight
                    ? 'bg-blue-500 hover:bg-blue-600 text-white'
                    : 'bg-slate-800 hover:bg-slate-700 text-white border border-slate-700'
                }`}
              >
                {service.cta}
              </Link>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function AutomationExamples() {
  const automations = [
    {
      icon: "⚡",
      title: "Instant Lead Response AI",
      description: "Every form fill gets an intelligent, personalized reply within 5 minutes—24/7. Your prospects feel heard immediately.",
      aiFeature: "AI analyzes inquiry intent and crafts contextual responses"
    },
    {
      icon: "🔍",
      title: "AI Meeting Prepper",
      description: "Before every sales call, receive a comprehensive briefing: company research, contact background, talking points.",
      aiFeature: "AI researches prospects across LinkedIn, news, and databases"
    },
    {
      icon: "✍️",
      title: "Content Creation Engine",
      description: "Transform voice notes or rough ideas into polished blog posts, emails, and social content automatically.",
      aiFeature: "AI maintains your voice while optimizing for engagement"
    },
    {
      icon: "📧",
      title: "Smart Follow-Up Sequences",
      description: "AI-powered email sequences that adapt based on prospect behavior and engagement patterns.",
      aiFeature: "AI adjusts timing and messaging based on open/click data"
    },
    {
      icon: "📄",
      title: "Document Intelligence",
      description: "Automatically extract data from PDFs, emails, and forms directly into your CRM or spreadsheets.",
      aiFeature: "AI understands document structure and extracts key fields"
    },
    {
      icon: "⭐",
      title: "Review Generation System",
      description: "Automatically request reviews at the perfect moment, with AI-crafted personalized messages.",
      aiFeature: "AI identifies optimal timing and tailors requests"
    }
  ];

  return (
    <section className="py-24 bg-slate-950 relative overflow-hidden">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(59,130,246,0.05),transparent_70%)]" />
      
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center mb-16">
          <h2 className="text-3xl sm:text-4xl font-bold text-white mb-4">
            AI Automation Examples
          </h2>
          <p className="text-xl text-slate-400 max-w-2xl mx-auto">
            These are just starting points. We build custom AI tools tailored to your exact workflow.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {automations.map((auto, index) => (
            <div key={index} className="group bg-slate-900/50 border border-slate-800 hover:border-blue-500/30 rounded-2xl p-6 transition-all hover:bg-slate-900/80">
              <div className="text-3xl mb-4">{auto.icon}</div>
              <h3 className="font-semibold text-lg text-white mb-2 group-hover:text-blue-400 transition-colors">{auto.title}</h3>
              <p className="text-slate-400 text-sm mb-4">{auto.description}</p>
              <div className="pt-4 border-t border-slate-800">
                <p className="text-xs text-blue-400 font-medium">{auto.aiFeature}</p>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-12 text-center">
          <p className="text-slate-500 mb-6">Have a different workflow? We'll build a custom AI solution for it.</p>
          <Link href="/contact" className="btn bg-blue-500 hover:bg-blue-600 text-white py-3 px-8 rounded-xl">
            Discuss Your Workflow
          </Link>
        </div>
      </div>
    </section>
  );
}

function Trust() {
  return (
    <section className="py-24 bg-slate-950 relative">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl sm:text-4xl font-bold text-white mb-4">
            Why Work With Flowstate AI?
          </h2>
          <p className="text-xl text-slate-400 max-w-2xl mx-auto">
            We don't sell software. We build AI systems that become your competitive advantage.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {[
            { icon: "🚀", title: "One Week to AI", desc: "From idea to working automation in 5-7 days. No lengthy projects." },
            { icon: "🎯", title: "Built For You", desc: "Every AI tool is custom-built for your specific workflow and goals." },
            { icon: "🏠", title: "Chicago Local", desc: "Based in Chicago. Available for in-person strategy sessions." },
            { icon: "🛡️", title: "Done-For-You", desc: "We handle everything. You get results without learning to code." }
          ].map((item, index) => (
            <div key={index} className="text-center">
              <div className="text-4xl mb-4">{item.icon}</div>
              <h3 className="font-semibold text-lg text-white mb-2">{item.title}</h3>
              <p className="text-slate-400">{item.desc}</p>
            </div>
          ))}
        </div>

        <div className="mt-20 text-center">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-blue-500/10 border border-blue-500/20 mb-4">
            <svg className="w-4 h-4 text-blue-400" fill="currentColor" viewBox="0 0 20 20">
              <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
            </svg>
            <span className="text-sm font-medium text-blue-300">Real AI Results, Not Promises</span>
          </div>
          <h3 className="text-2xl font-bold text-white mb-4">Be Our Next Success Story</h3>
          <p className="text-slate-400 max-w-xl mx-auto mb-8">
            Flowstate AI is new, but our founder comes from technology consulting where he helped PE firms 
            identify AI value creation opportunities. Let's make your business our next case study.
          </p>
          <Link href="/contact" className="btn bg-slate-800 hover:bg-slate-700 text-white border border-slate-700 py-3 px-8 rounded-xl">
            Let's Talk AI
          </Link>
        </div>
      </div>
    </section>
  );
}

function CTA() {
  return (
    <section className="py-24 bg-gradient-to-b from-slate-950 to-slate-900 relative overflow-hidden">
      <div className="absolute inset-0">
        <div className="absolute top-0 left-1/2 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl -translate-x-1/2" />
      </div>
      
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
        <h2 className="text-3xl sm:text-4xl font-bold text-white mb-4">
          Ready to Transform Your Business with AI?
        </h2>
        <p className="text-xl text-slate-400 mb-8">
          20-minute AI audit. We'll identify 2-3 high-impact automations specific to your workflow.
          <br />
          No pitch. Just actionable AI insights.
        </p>

        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Link
            href="/contact"
            className="btn bg-blue-500 hover:bg-blue-600 text-white px-8 py-4 rounded-xl font-semibold text-lg shadow-lg shadow-blue-500/25 transition-all"
          >
            Get Your Free AI Audit
          </Link>
        </div>

        <p className="text-slate-500 mt-6 text-sm">
          Or email directly: <a href="mailto:hello@flowstateai.io" className="text-blue-400 hover:text-blue-300">hello@flowstateai.io</a>
        </p>
      </div>
    </section>
  );
}
